<?php
session_start();
require_once '../config/database.php';

// Check if user is logged in as admin
if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit();
}

// Handle bypass toggle
if ($_POST['action'] ?? '' === 'toggle_bypass') {
    $bypass_status = $_POST['bypass_enabled'] === '1' ? 'enabled' : 'disabled';
    
    // Update bypass status in database or config file
    $stmt = $conn->prepare("INSERT INTO website_settings (setting_name, setting_value) VALUES ('bypass_login_enabled', ?) ON DUPLICATE KEY UPDATE setting_value = ?");
    $stmt->bind_param("ss", $bypass_status, $bypass_status);
    $stmt->execute();
    
    $message = "Bypass login has been " . $bypass_status;
}

// Get current bypass status
$stmt = $conn->prepare("SELECT setting_value FROM website_settings WHERE setting_name = 'bypass_login_enabled'");
$stmt->execute();
$result = $stmt->get_result();
$bypass_enabled = $result->num_rows > 0 ? $result->fetch_assoc()['setting_value'] === 'enabled' : true;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Security Settings - Admin Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../assets/css/admin.css" rel="stylesheet">
</head>
<body>
    <div class="wrapper">
        <!-- Include sidebar here -->
        <nav id="sidebar" class="sidebar">
            <div class="sidebar-header">
                <h3><i class="fas fa-cog"></i> Admin Panel</h3>
            </div>
            <ul class="list-unstyled components">
                <li><a href="index.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                <li><a href="users.php"><i class="fas fa-users"></i> Users</a></li>
                <li><a href="products.php"><i class="fas fa-box"></i> Products</a></li>
                <li><a href="generate_bypass_link.php"><i class="fas fa-link"></i> Bypass Links</a></li>
                <li class="active"><a href="security_settings.php"><i class="fas fa-shield-alt"></i> Security</a></li>
                <li><a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
            </ul>
        </nav>

        <div id="content">
            <div class="container-fluid">
                <h1 class="h3 mb-4">Security Settings</h1>
                
                <?php if (isset($message)): ?>
                <div class="alert alert-success alert-dismissible fade show">
                    <?php echo $message; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
                <?php endif; ?>
                
                <div class="row">
                    <div class="col-md-6">
                        <div class="card">
                            <div class="card-header">
                                <h5><i class="fas fa-key"></i> Bypass Login Settings</h5>
                            </div>
                            <div class="card-body">
                                <form method="POST">
                                    <input type="hidden" name="action" value="toggle_bypass">
                                    
                                    <div class="form-check form-switch mb-3">
                                        <input class="form-check-input" type="checkbox" 
                                               name="bypass_enabled" value="1" 
                                               <?php echo $bypass_enabled ? 'checked' : ''; ?>>
                                        <label class="form-check-label">
                                            Enable Bypass Login
                                        </label>
                                    </div>
                                    
                                    <p class="text-muted">
                                        When enabled, special links can be used to access admin panel without password.
                                    </p>
                                    
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fas fa-save"></i> Save Settings
                                    </button>
                                    
                                    <?php if ($bypass_enabled): ?>
                                    <a href="generate_bypass_link.php" class="btn btn-success">
                                        <i class="fas fa-link"></i> Generate Links
                                    </a>
                                    <?php endif; ?>
                                </form>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-6">
                        <div class="card">
                            <div class="card-header">
                                <h5><i class="fas fa-info-circle"></i> Security Information</h5>
                            </div>
                            <div class="card-body">
                                <h6>Bypass Login Status:</h6>
                                <span class="badge bg-<?php echo $bypass_enabled ? 'success' : 'danger'; ?>">
                                    <?php echo $bypass_enabled ? 'Enabled' : 'Disabled'; ?>
                                </span>
                                
                                <hr>
                                
                                <h6>Security Tips:</h6>
                                <ul class="list-unstyled">
                                    <li><i class="fas fa-check text-success"></i> Keep bypass links private</li>
                                    <li><i class="fas fa-check text-success"></i> Monitor access logs regularly</li>
                                    <li><i class="fas fa-check text-success"></i> Disable bypass when not needed</li>
                                    <li><i class="fas fa-check text-success"></i> Change admin passwords regularly</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>