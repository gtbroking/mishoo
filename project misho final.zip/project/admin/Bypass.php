<?php
session_start();
require_once '../config/database.php';

// Security: Check if bypass is enabled and valid
$bypass_enabled = true; // Set to false to disable bypass login
$valid_tokens = [
    'admin_direct_2024',
    'secure_admin_access',
    'bypass_login_key'
];

// Get token from URL
$token = $_GET['token'] ?? '';

if (!$bypass_enabled) {
    die('Bypass login is disabled');
}

if (empty($token) || !in_array($token, $valid_tokens)) {
    die('Invalid or missing access token');
}

// Get admin details from database
$stmt = $conn->prepare("SELECT id, username FROM admin LIMIT 1");
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $admin = $result->fetch_assoc();
    
    // Set admin session
    $_SESSION['admin_id'] = $admin['id'];
    $_SESSION['admin_username'] = $admin['username'];
    $_SESSION['bypass_login'] = true;
    
    // Log the bypass access
    $ip_address = $_SERVER['REMOTE_ADDR'] ?? 'Unknown';
    $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown';
    $access_time = date('Y-m-d H:i:s');
    
    // You can log this to a file or database for security monitoring
    $log_entry = "Bypass Login - Time: $access_time, IP: $ip_address, Token: $token, User Agent: $user_agent\n";
    file_put_contents('../logs/bypass_access.log', $log_entry, FILE_APPEND | LOCK_EX);
    
    // Redirect to admin dashboard
    header('Location: index.php?bypass=success');
    exit();
} else {
    die('Admin account not found');
}
?>