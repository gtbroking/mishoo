<?php
session_start();
require_once '../config/database.php';

// Check if user is already logged in as admin
if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit();
}

// Available tokens for bypass links
$tokens = [
    'admin_direct_2024',
    'secure_admin_access', 
    'bypass_login_key'
];

// Get current domain
$protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http';
$domain = $_SERVER['HTTP_HOST'];
$base_url = $protocol . '://' . $domain;

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Generate Bypass Links - Admin Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../assets/css/admin.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header bg-primary text-white">
                        <h4><i class="fas fa-link"></i> Generate Admin Bypass Links</h4>
                    </div>
                    <div class="card-body">
                        <div class="alert alert-warning">
                            <i class="fas fa-exclamation-triangle"></i>
                            <strong>Security Warning:</strong> These links provide direct admin access without password. Keep them secure and don't share publicly.
                        </div>
                        
                        <h5>Available Bypass Links:</h5>
                        
                        <?php foreach ($tokens as $index => $token): ?>
                        <div class="mb-4 p-3 border rounded">
                            <h6>Bypass Link #<?php echo ($index + 1); ?></h6>
                            <div class="input-group">
                                <input type="text" class="form-control" 
                                       value="<?php echo $base_url; ?>/admin/bypass.php?token=<?php echo $token; ?>" 
                                       id="link<?php echo $index; ?>" readonly>
                                <button class="btn btn-outline-primary" onclick="copyLink('link<?php echo $index; ?>')">
                                    <i class="fas fa-copy"></i> Copy
                                </button>
                                <button class="btn btn-outline-success" onclick="testLink('<?php echo $token; ?>')">
                                    <i class="fas fa-external-link-alt"></i> Test
                                </button>
                            </div>
                            <small class="text-muted">Token: <?php echo $token; ?></small>
                        </div>
                        <?php endforeach; ?>
                        
                        <hr>
                        
                        <h5>Quick Access Buttons:</h5>
                        <div class="row">
                            <?php foreach ($tokens as $index => $token): ?>
                            <div class="col-md-4 mb-2">
                                <a href="bypass.php?token=<?php echo $token; ?>" 
                                   class="btn btn-success w-100" target="_blank">
                                    <i class="fas fa-sign-in-alt"></i> Direct Login #<?php echo ($index + 1); ?>
                                </a>
                            </div>
                            <?php endforeach; ?>
                        </div>
                        
                        <hr>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <a href="index.php" class="btn btn-secondary">
                                    <i class="fas fa-arrow-left"></i> Back to Dashboard
                                </a>
                            </div>
                            <div class="col-md-6 text-end">
                                <button class="btn btn-danger" onclick="disableBypass()">
                                    <i class="fas fa-ban"></i> Disable Bypass Login
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Access Log -->
                <div class="card mt-4">
                    <div class="card-header">
                        <h5><i class="fas fa-history"></i> Recent Bypass Access Log</h5>
                    </div>
                    <div class="card-body">
                        <div id="accessLog">
                            <?php
                            $log_file = '../logs/bypass_access.log';
                            if (file_exists($log_file)) {
                                $logs = file($log_file, FILE_IGNORE_NEW_LINES);
                                $recent_logs = array_slice(array_reverse($logs), 0, 10);
                                
                                if (!empty($recent_logs)) {
                                    echo '<ul class="list-group">';
                                    foreach ($recent_logs as $log) {
                                        echo '<li class="list-group-item"><small>' . htmlspecialchars($log) . '</small></li>';
                                    }
                                    echo '</ul>';
                                } else {
                                    echo '<p class="text-muted">No bypass access recorded yet.</p>';
                                }
                            } else {
                                echo '<p class="text-muted">Log file not found.</p>';
                            }
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function copyLink(elementId) {
            const element = document.getElementById(elementId);
            element.select();
            element.setSelectionRange(0, 99999);
            document.execCommand('copy');
            
            // Show success message
            const button = element.nextElementSibling;
            const originalText = button.innerHTML;
            button.innerHTML = '<i class="fas fa-check"></i> Copied!';
            button.classList.remove('btn-outline-primary');
            button.classList.add('btn-success');
            
            setTimeout(() => {
                button.innerHTML = originalText;
                button.classList.remove('btn-success');
                button.classList.add('btn-outline-primary');
            }, 2000);
        }
        
        function testLink(token) {
            const url = `bypass.php?token=${token}`;
            window.open(url, '_blank');
        }
        
        function disableBypass() {
            if (confirm('Are you sure you want to disable bypass login? This will make all bypass links inactive.')) {
                // You can implement this functionality to disable bypass
                alert('Contact developer to disable bypass login functionality.');
            }
        }
    </script>
</body>
</html>