// Global variables
let cart = [];
let wishlist = [];

// Initialize when page loads
document.addEventListener('DOMContentLoaded', function() {
    loadCart();
    loadWishlist();
    updateCartCount();
    
    // Initialize tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
});

// Search functionality
function searchProducts() {
    const searchTerm = document.getElementById('searchInput').value.trim();
    if (searchTerm === '') {
        alert('Please enter a search term');
        return;
    }
    
    // Redirect to search results page
    window.location.href = `search.php?q=${encodeURIComponent(searchTerm)}`;
}

// Add to cart functionality
function addToCart(productId) {
    if (!isLoggedIn()) {
        alert('Please login to add items to cart');
        window.location.href = 'login.php';
        return;
    }
    
    showLoading();
    
    fetch('ajax/cart.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `action=add&product_id=${productId}`
    })
    .then(response => response.json())
    .then(data => {
        hideLoading();
        if (data.success) {
            showNotification('Product added to cart successfully!', 'success');
            updateCartCount();
            animateCartButton();
        } else {
            showNotification(data.message || 'Error adding product to cart', 'error');
        }
    })
    .catch(error => {
        hideLoading();
        console.error('Error:', error);
        showNotification('Error adding product to cart', 'error');
    });
}

// Add to wishlist functionality
function addToWishlist(productId) {
    if (!isLoggedIn()) {
        alert('Please login to add items to wishlist');
        window.location.href = 'login.php';
        return;
    }
    
    showLoading();
    
    fetch('ajax/wishlist.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `action=add&product_id=${productId}`
    })
    .then(response => response.json())
    .then(data => {
        hideLoading();
        if (data.success) {
            showNotification('Product added to wishlist!', 'success');
            // Update wishlist icon
            const heartIcon = document.querySelector(`[onclick="addToWishlist(${productId})"] i`);
            if (heartIcon) {
                heartIcon.classList.add('fas', 'text-danger');
                heartIcon.classList.remove('far');
            }
        } else {
            showNotification(data.message || 'Error adding product to wishlist', 'error');
        }
    })
    .catch(error => {
        hideLoading();
        console.error('Error:', error);
        showNotification('Error adding product to wishlist', 'error');
    });
}

// Buy now functionality
function buyNow(productId) {
    if (!isLoggedIn()) {
        alert('Please login to buy products');
        window.location.href = 'login.php';
        return;
    }
    
    // Add to cart first, then redirect to checkout
    addToCart(productId);
    setTimeout(() => {
        window.location.href = 'checkout.php';
    }, 1000);
}

// Inquiry now functionality
function inquiryNow(productId) {
    const whatsappNumber = '+919876543210'; // From settings
    const message = `Hi, I'm interested in product ID: ${productId}. Please provide more details.`;
    const whatsappUrl = `https://wa.me/${whatsappNumber}?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, '_blank');
}

// Quick view functionality
function quickView(productId) {
    showLoading();
    
    fetch(`ajax/product_details.php?id=${productId}`)
    .then(response => response.json())
    .then(data => {
        hideLoading();
        if (data.success) {
            showQuickViewModal(data.product);
        } else {
            showNotification('Error loading product details', 'error');
        }
    })
    .catch(error => {
        hideLoading();
        console.error('Error:', error);
        showNotification('Error loading product details', 'error');
    });
}

// Show quick view modal
function showQuickViewModal(product) {
    const modal = document.createElement('div');
    modal.className = 'modal fade';
    modal.id = 'quickViewModal';
    modal.innerHTML = `
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">${product.name}</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6">
                            <img src="assets/images/products/${product.image}" class="img-fluid rounded" alt="${product.name}">
                        </div>
                        <div class="col-md-6">
                            <h4>${product.name}</h4>
                            <p class="text-muted">${product.category_name}</p>
                            <p>${product.description}</p>
                            <div class="price-section mb-3">
                                ${product.discount_price > 0 ? 
                                    `<span class="h4 text-success">₹${product.discount_price}</span>
                                     <span class="text-muted text-decoration-line-through ms-2">₹${product.price}</span>` :
                                    `<span class="h4 text-primary">₹${product.price}</span>`
                                }
                            </div>
                            <div class="points-section mb-3">
                                <span class="badge bg-warning">
                                    <i class="fas fa-star"></i> Earn ${product.points_reward} points
                                </span>
                            </div>
                            <div class="action-buttons">
                                <button class="btn btn-primary me-2" onclick="addToCart(${product.id}); closeModal('quickViewModal')">
                                    <i class="fas fa-cart-plus"></i> Add to Cart
                                </button>
                                <button class="btn btn-success" onclick="buyNow(${product.id}); closeModal('quickViewModal')">
                                    <i class="fas fa-bolt"></i> Buy Now
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    const bootstrapModal = new bootstrap.Modal(modal);
    bootstrapModal.show();
    
    // Remove modal from DOM when closed
    modal.addEventListener('hidden.bs.modal', function() {
        document.body.removeChild(modal);
    });
}

// Filter by category
function filterByCategory(categoryId) {
    window.location.href = `products.php?category=${categoryId}`;
}

// Load cart from localStorage
function loadCart() {
    const savedCart = localStorage.getItem('shopping_cart');
    if (savedCart) {
        cart = JSON.parse(savedCart);
    }
}

// Save cart to localStorage
function saveCart() {
    localStorage.setItem('shopping_cart', JSON.stringify(cart));
}

// Load wishlist from localStorage
function loadWishlist() {
    const savedWishlist = localStorage.getItem('wishlist');
    if (savedWishlist) {
        wishlist = JSON.parse(savedWishlist);
    }
}

// Save wishlist to localStorage
function saveWishlist() {
    localStorage.setItem('wishlist', JSON.stringify(wishlist));
}

// Update cart count
function updateCartCount() {
    if (isLoggedIn()) {
        fetch('ajax/cart.php?action=count')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                document.getElementById('cartCount').textContent = data.count;
            }
        })
        .catch(error => console.error('Error updating cart count:', error));
    }
}

// Animate cart button
function animateCartButton() {
    const cartButton = document.querySelector('a[href="cart.php"]');
    if (cartButton) {
        cartButton.classList.add('animate__animated', 'animate__bounce');
        setTimeout(() => {
            cartButton.classList.remove('animate__animated', 'animate__bounce');
        }, 1000);
    }
}

// Show notification
function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `alert alert-${type === 'error' ? 'danger' : type} alert-dismissible fade show notification`;
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        z-index: 9999;
        min-width: 300px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.3);
    `;
    notification.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    document.body.appendChild(notification);
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        if (notification.parentNode) {
            notification.parentNode.removeChild(notification);
        }
    }, 5000);
}

// Show loading
function showLoading() {
    const loading = document.createElement('div');
    loading.id = 'loadingOverlay';
    loading.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0,0,0,0.5);
        display: flex;
        justify-content: center;
        align-items: center;
        z-index: 9999;
    `;
    loading.innerHTML = '<div class="spinner"></div>';
    document.body.appendChild(loading);
}

// Hide loading
function hideLoading() {
    const loading = document.getElementById('loadingOverlay');
    if (loading) {
        loading.parentNode.removeChild(loading);
    }
}

// Check if user is logged in
function isLoggedIn() {
    return document.querySelector('.dropdown-toggle') !== null;
}

// Close modal
function closeModal(modalId) {
    const modal = bootstrap.Modal.getInstance(document.getElementById(modalId));
    if (modal) {
        modal.hide();
    }
}

// Password strength checker
function checkPasswordStrength(password) {
    const strengthIndicator = document.getElementById('passwordStrength');
    if (!strengthIndicator) return;
    
    let strength = 0;
    let feedback = '';
    
    // Length check
    if (password.length >= 8) strength += 1;
    else feedback += 'At least 8 characters. ';
    
    // Uppercase check
    if (/[A-Z]/.test(password)) strength += 1;
    else feedback += 'One uppercase letter. ';
    
    // Lowercase check
    if (/[a-z]/.test(password)) strength += 1;
    else feedback += 'One lowercase letter. ';
    
    // Number check
    if (/\d/.test(password)) strength += 1;
    else feedback += 'One number. ';
    
    // Special character check
    if (/[!@#$%^&*]/.test(password)) strength += 1;
    else feedback += 'One special character. ';
    
    const strengthLevels = ['Very Weak', 'Weak', 'Fair', 'Good', 'Strong'];
    const strengthColors = ['danger', 'warning', 'info', 'primary', 'success'];
    
    strengthIndicator.textContent = `Password Strength: ${strengthLevels[strength - 1] || 'Very Weak'}`;
    strengthIndicator.className = `text-${strengthColors[strength - 1] || 'danger'}`;
    
    if (feedback) {
        strengthIndicator.textContent += ` - Missing: ${feedback}`;
    }
}

// Form validation
function validateForm(formId) {
    const form = document.getElementById(formId);
    const inputs = form.querySelectorAll('input[required], select[required], textarea[required]');
    let isValid = true;
    
    inputs.forEach(input => {
        if (!input.value.trim()) {
            input.classList.add('is-invalid');
            isValid = false;
        } else {
            input.classList.remove('is-invalid');
            input.classList.add('is-valid');
        }
    });
    
    return isValid;
}

// Format currency
function formatCurrency(amount) {
    return new Intl.NumberFormat('en-IN', {
        style: 'currency',
        currency: 'INR'
    }).format(amount);
}

// Debounce function for search
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Auto-complete search
const debouncedSearch = debounce(function(query) {
    if (query.length < 2) return;
    
    fetch(`ajax/search_suggestions.php?q=${encodeURIComponent(query)}`)
    .then(response => response.json())
    .then(data => {
        showSearchSuggestions(data.suggestions);
    })
    .catch(error => console.error('Search error:', error));
}, 300);

// Show search suggestions
function showSearchSuggestions(suggestions) {
    const searchInput = document.getElementById('searchInput');
    let dropdown = document.getElementById('searchDropdown');
    
    if (!dropdown) {
        dropdown = document.createElement('div');
        dropdown.id = 'searchDropdown';
        dropdown.className = 'search-dropdown';
        dropdown.style.cssText = `
            position: absolute;
            top: 100%;
            left: 0;
            right: 0;
            background: white;
            border: 1px solid #ddd;
            border-radius: 0 0 10px 10px;
            max-height: 200px;
            overflow-y: auto;
            z-index: 1000;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        `;
        searchInput.parentNode.appendChild(dropdown);
    }
    
    dropdown.innerHTML = '';
    
    suggestions.forEach(suggestion => {
        const item = document.createElement('div');
        item.className = 'search-suggestion-item';
        item.style.cssText = `
            padding: 10px 15px;
            cursor: pointer;
            border-bottom: 1px solid #eee;
        `;
        item.textContent = suggestion;
        item.addEventListener('click', () => {
            searchInput.value = suggestion;
            dropdown.style.display = 'none';
            searchProducts();
        });
        dropdown.appendChild(item);
    });
}

// Hide search suggestions when clicking outside
document.addEventListener('click', function(e) {
    const dropdown = document.getElementById('searchDropdown');
    const searchInput = document.getElementById('searchInput');
    
    if (dropdown && !searchInput.contains(e.target) && !dropdown.contains(e.target)) {
        dropdown.style.display = 'none';
    }
});

// Search input event listener
document.getElementById('searchInput')?.addEventListener('input', function(e) {
    debouncedSearch(e.target.value);
});

// Enter key search
document.getElementById('searchInput')?.addEventListener('keypress', function(e) {
    if (e.key === 'Enter') {
        searchProducts();
    }
});

// Smooth scrolling for anchor links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth'
            });
        }
    });
});

// Back to top button
const backToTopButton = document.createElement('button');
backToTopButton.innerHTML = '<i class="fas fa-arrow-up"></i>';
backToTopButton.className = 'btn btn-primary back-to-top';
backToTopButton.style.cssText = `
    position: fixed;
    bottom: 20px;
    right: 20px;
    width: 50px;
    height: 50px;
    border-radius: 50%;
    display: none;
    z-index: 999;
    box-shadow: 0 4px 12px rgba(0,0,0,0.3);
`;

document.body.appendChild(backToTopButton);

// Show/hide back to top button
window.addEventListener('scroll', function() {
    if (window.pageYOffset > 300) {
        backToTopButton.style.display = 'block';
    } else {
        backToTopButton.style.display = 'none';
    }
});

// Back to top functionality
backToTopButton.addEventListener('click', function() {
    window.scrollTo({
        top: 0,
        behavior: 'smooth'
    });
});

// Image lazy loading
function lazyLoadImages() {
    const images = document.querySelectorAll('img[data-src]');
    const imageObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const img = entry.target;
                img.src = img.dataset.src;
                img.classList.remove('lazy');
                imageObserver.unobserve(img);
            }
        });
    });
    
    images.forEach(img => imageObserver.observe(img));
}

// Initialize lazy loading
document.addEventListener('DOMContentLoaded', lazyLoadImages);

// Service worker registration for PWA
if ('serviceWorker' in navigator) {
    window.addEventListener('load', function() {
        navigator.serviceWorker.register('/service-worker.js')
        .then(function(registration) {
            console.log('ServiceWorker registration successful');
        })
        .catch(function(err) {
            console.log('ServiceWorker registration failed: ', err);
        });
    });
}