// Admin Panel JavaScript
document.addEventListener('DOMContentLoaded', function() {
    // Sidebar toggle functionality
    const sidebarCollapse = document.getElementById('sidebarCollapse');
    const sidebar = document.getElementById('sidebar');
    const content = document.getElementById('content');
    
    if (sidebarCollapse) {
        sidebarCollapse.addEventListener('click', function() {
            sidebar.classList.toggle('active');
            content.classList.toggle('active');
        });
    }
    
    // Initialize tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
    
    // Initialize charts if chart.js is available
    if (typeof Chart !== 'undefined') {
        initializeCharts();
    }
    
    // Auto-refresh notifications
    setInterval(checkNotifications, 30000);
});

// Charts initialization
function initializeCharts() {
    // Sales Chart
    const salesCtx = document.getElementById('salesChart');
    if (salesCtx) {
        new Chart(salesCtx, {
            type: 'line',
            data: {
                labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
                datasets: [{
                    label: 'Sales',
                    data: [12, 19, 3, 5, 2, 3],
                    borderColor: '#007bff',
                    backgroundColor: 'rgba(0, 123, 255, 0.1)',
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    title: {
                        display: true,
                        text: 'Monthly Sales'
                    }
                }
            }
        });
    }
    
    // Users Chart
    const usersCtx = document.getElementById('usersChart');
    if (usersCtx) {
        new Chart(usersCtx, {
            type: 'doughnut',
            data: {
                labels: ['Silver', 'Gold', 'Platinum', 'Elite'],
                datasets: [{
                    data: [300, 150, 100, 50],
                    backgroundColor: [
                        '#6c757d',
                        '#ffc107',
                        '#17a2b8',
                        '#dc3545'
                    ]
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    title: {
                        display: true,
                        text: 'Users by Badge'
                    }
                }
            }
        });
    }
}

// Notification functions
function checkNotifications() {
    fetch('ajax/notifications.php')
        .then(response => response.json())
        .then(data => {
            if (data.notifications && data.notifications.length > 0) {
                showNotifications(data.notifications);
            }
        })
        .catch(error => console.error('Error checking notifications:', error));
}

function showNotifications(notifications) {
    const notificationContainer = document.getElementById('notificationContainer');
    if (!notificationContainer) return;
    
    notifications.forEach(notification => {
        const notificationElement = createNotificationElement(notification);
        notificationContainer.appendChild(notificationElement);
    });
}

function createNotificationElement(notification) {
    const div = document.createElement('div');
    div.className = `alert alert-${notification.type} alert-dismissible fade show`;
    div.innerHTML = `
        <strong>${notification.title}</strong> ${notification.message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    return div;
}

// AJAX functions for common operations
function updateUserStatus(userId, status) {
    showLoading();
    
    fetch('ajax/update_user_status.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `user_id=${userId}&status=${status}`
    })
    .then(response => response.json())
    .then(data => {
        hideLoading();
        if (data.success) {
            showAlert('User status updated successfully!', 'success');
            setTimeout(() => location.reload(), 1000);
        } else {
            showAlert(data.message || 'Error updating user status', 'danger');
        }
    })
    .catch(error => {
        hideLoading();
        console.error('Error:', error);
        showAlert('Error updating user status', 'danger');
    });
}

function updateUserBadge(userId, badge) {
    showLoading();
    
    fetch('ajax/update_user_badge.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `user_id=${userId}&badge=${badge}`
    })
    .then(response => response.json())
    .then(data => {
        hideLoading();
        if (data.success) {
            showAlert('User badge updated successfully!', 'success');
            setTimeout(() => location.reload(), 1000);
        } else {
            showAlert(data.message || 'Error updating user badge', 'danger');
        }
    })
    .catch(error => {
        hideLoading();
        console.error('Error:', error);
        showAlert('Error updating user badge', 'danger');
    });
}

function addPointsToUser(userId, points, description) {
    showLoading();
    
    fetch('ajax/add_points.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `user_id=${userId}&points=${points}&description=${encodeURIComponent(description)}`
    })
    .then(response => response.json())
    .then(data => {
        hideLoading();
        if (data.success) {
            showAlert('Points added successfully!', 'success');
            setTimeout(() => location.reload(), 1000);
        } else {
            showAlert(data.message || 'Error adding points', 'danger');
        }
    })
    .catch(error => {
        hideLoading();
        console.error('Error:', error);
        showAlert('Error adding points', 'danger');
    });
}

function updateOrderStatus(orderId, status) {
    showLoading();
    
    fetch('ajax/update_order_status.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `order_id=${orderId}&status=${status}`
    })
    .then(response => response.json())
    .then(data => {
        hideLoading();
        if (data.success) {
            showAlert('Order status updated successfully!', 'success');
            setTimeout(() => location.reload(), 1000);
        } else {
            showAlert(data.message || 'Error updating order status', 'danger');
        }
    })
    .catch(error => {
        hideLoading();
        console.error('Error:', error);
        showAlert('Error updating order status', 'danger');
    });
}

function approveRedemption(requestId) {
    if (!confirm('Are you sure you want to approve this redemption request?')) {
        return;
    }
    
    showLoading();
    
    fetch('ajax/process_redemption.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `request_id=${requestId}&action=approve`
    })
    .then(response => response.json())
    .then(data => {
        hideLoading();
        if (data.success) {
            showAlert('Redemption request approved successfully!', 'success');
            setTimeout(() => location.reload(), 1000);
        } else {
            showAlert(data.message || 'Error approving redemption request', 'danger');
        }
    })
    .catch(error => {
        hideLoading();
        console.error('Error:', error);
        showAlert('Error approving redemption request', 'danger');
    });
}

function rejectRedemption(requestId) {
    if (!confirm('Are you sure you want to reject this redemption request?')) {
        return;
    }
    
    showLoading();
    
    fetch('ajax/process_redemption.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `request_id=${requestId}&action=reject`
    })
    .then(response => response.json())
    .then(data => {
        hideLoading();
        if (data.success) {
            showAlert('Redemption request rejected successfully!', 'success');
            setTimeout(() => location.reload(), 1000);
        } else {
            showAlert(data.message || 'Error rejecting redemption request', 'danger');
        }
    })
    .catch(error => {
        hideLoading();
        console.error('Error:', error);
        showAlert('Error rejecting redemption request', 'danger');
    });
}

// Product management functions
function deleteProduct(productId) {
    if (!confirm('Are you sure you want to delete this product?')) {
        return;
    }
    
    showLoading();
    
    fetch('ajax/delete_product.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `product_id=${productId}`
    })
    .then(response => response.json())
    .then(data => {
        hideLoading();
        if (data.success) {
            showAlert('Product deleted successfully!', 'success');
            setTimeout(() => location.reload(), 1000);
        } else {
            showAlert(data.message || 'Error deleting product', 'danger');
        }
    })
    .catch(error => {
        hideLoading();
        console.error('Error:', error);
        showAlert('Error deleting product', 'danger');
    });
}

function toggleProductStatus(productId) {
    showLoading();
    
    fetch('ajax/toggle_product_status.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `product_id=${productId}`
    })
    .then(response => response.json())
    .then(data => {
        hideLoading();
        if (data.success) {
            showAlert('Product status updated successfully!', 'success');
            setTimeout(() => location.reload(), 1000);
        } else {
            showAlert(data.message || 'Error updating product status', 'danger');
        }
    })
    .catch(error => {
        hideLoading();
        console.error('Error:', error);
        showAlert('Error updating product status', 'danger');
    });
}

// Settings functions
function updateSetting(settingName, settingValue) {
    showLoading();
    
    fetch('ajax/update_setting.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `setting_name=${settingName}&setting_value=${encodeURIComponent(settingValue)}`
    })
    .then(response => response.json())
    .then(data => {
        hideLoading();
        if (data.success) {
            showAlert('Setting updated successfully!', 'success');
        } else {
            showAlert(data.message || 'Error updating setting', 'danger');
        }
    })
    .catch(error => {
        hideLoading();
        console.error('Error:', error);
        showAlert('Error updating setting', 'danger');
    });
}

// Utility functions
function showLoading() {
    const loading = document.createElement('div');
    loading.id = 'loadingOverlay';
    loading.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0,0,0,0.5);
        display: flex;
        justify-content: center;
        align-items: center;
        z-index: 9999;
    `;
    loading.innerHTML = '<div class="spinner"></div>';
    document.body.appendChild(loading);
}

function hideLoading() {
    const loading = document.getElementById('loadingOverlay');
    if (loading) {
        loading.parentNode.removeChild(loading);
    }
}

function showAlert(message, type = 'info') {
    const alert = document.createElement('div');
    alert.className = `alert alert-${type} alert-dismissible fade show`;
    alert.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        z-index: 9999;
        min-width: 300px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.3);
    `;
    alert.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    document.body.appendChild(alert);
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        if (alert.parentNode) {
            alert.parentNode.removeChild(alert);
        }
    }, 5000);
}

// Form validation
function validateForm(formId) {
    const form = document.getElementById(formId);
    const inputs = form.querySelectorAll('input[required], select[required], textarea[required]');
    let isValid = true;
    
    inputs.forEach(input => {
        if (!input.value.trim()) {
            input.classList.add('is-invalid');
            isValid = false;
        } else {
            input.classList.remove('is-invalid');
            input.classList.add('is-valid');
        }
    });
    
    return isValid;
}

// Image preview
function previewImage(input, previewId) {
    if (input.files && input.files[0]) {
        const reader = new FileReader();
        reader.onload = function(e) {
            document.getElementById(previewId).src = e.target.result;
        };
        reader.readAsDataURL(input.files[0]);
    }
}

// Data table initialization
function initializeDataTable(tableId) {
    if (typeof DataTable !== 'undefined') {
        new DataTable(`#${tableId}`, {
            responsive: true,
            pageLength: 25,
            order: [[0, 'desc']],
            language: {
                search: "Search:",
                lengthMenu: "Show _MENU_ entries",
                info: "Showing _START_ to _END_ of _TOTAL_ entries",
                paginate: {
                    first: "First",
                    last: "Last",
                    next: "Next",
                    previous: "Previous"
                }
            }
        });
    }
}

// Export functions
function exportData(format, tableId) {
    const table = document.getElementById(tableId);
    if (!table) return;
    
    let data = '';
    const rows = table.querySelectorAll('tr');
    
    if (format === 'csv') {
        rows.forEach(row => {
            const cols = row.querySelectorAll('td, th');
            const rowData = Array.from(cols).map(col => col.textContent.trim()).join(',');
            data += rowData + '\n';
        });
        downloadFile(data, 'data.csv', 'text/csv');
    } else if (format === 'json') {
        const headers = Array.from(rows[0].querySelectorAll('th')).map(th => th.textContent.trim());
        const jsonData = [];
        
        for (let i = 1; i < rows.length; i++) {
            const row = rows[i];
            const cols = row.querySelectorAll('td');
            const rowData = {};
            
            headers.forEach((header, index) => {
                rowData[header] = cols[index]?.textContent.trim() || '';
            });
            
            jsonData.push(rowData);
        }
        
        downloadFile(JSON.stringify(jsonData, null, 2), 'data.json', 'application/json');
    }
}

function downloadFile(content, filename, contentType) {
    const blob = new Blob([content], { type: contentType });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
}

// Search functionality
function searchTable(inputId, tableId) {
    const input = document.getElementById(inputId);
    const table = document.getElementById(tableId);
    const rows = table.querySelectorAll('tbody tr');
    
    input.addEventListener('keyup', function() {
        const searchTerm = this.value.toLowerCase();
        
        rows.forEach(row => {
            const text = row.textContent.toLowerCase();
            row.style.display = text.includes(searchTerm) ? '' : 'none';
        });
    });
}

// Auto-save functionality
function autoSave(formId, saveUrl) {
    const form = document.getElementById(formId);
    const inputs = form.querySelectorAll('input, select, textarea');
    
    inputs.forEach(input => {
        input.addEventListener('change', function() {
            const formData = new FormData(form);
            
            fetch(saveUrl, {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showAlert('Changes saved automatically', 'success');
                }
            })
            .catch(error => {
                console.error('Auto-save error:', error);
            });
        });
    });
}

// Real-time updates
function startRealTimeUpdates() {
    setInterval(() => {
        updateDashboardStats();
        updateNotifications();
    }, 60000); // Update every minute
}

function updateDashboardStats() {
    fetch('ajax/dashboard_stats.php')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                updateStatCards(data.stats);
            }
        })
        .catch(error => console.error('Error updating dashboard stats:', error));
}

function updateStatCards(stats) {
    Object.keys(stats).forEach(key => {
        const element = document.getElementById(`stat-${key}`);
        if (element) {
            element.textContent = stats[key];
        }
    });
}

function updateNotifications() {
    fetch('ajax/notifications.php')
        .then(response => response.json())
        .then(data => {
            if (data.notifications && data.notifications.length > 0) {
                updateNotificationBadge(data.notifications.length);
            }
        })
        .catch(error => console.error('Error updating notifications:', error));
}

function updateNotificationBadge(count) {
    const badge = document.getElementById('notificationBadge');
    if (badge) {
        badge.textContent = count;
        badge.style.display = count > 0 ? 'inline' : 'none';
    }
}

// Initialize everything when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    // Initialize data tables
    document.querySelectorAll('[data-table="true"]').forEach(table => {
        initializeDataTable(table.id);
    });
    
    // Initialize search functionality
    document.querySelectorAll('[data-search]').forEach(input => {
        const tableId = input.getAttribute('data-search');
        searchTable(input.id, tableId);
    });
    
    // Initialize auto-save
    document.querySelectorAll('[data-auto-save]').forEach(form => {
        const saveUrl = form.getAttribute('data-auto-save');
        autoSave(form.id, saveUrl);
    });
    
    // Start real-time updates
    startRealTimeUpdates();
});