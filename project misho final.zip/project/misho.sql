-- ========================================
-- SHOPEASY DATABASE TABLES FOR HOSTINGER
-- ========================================
-- Import this file after selecting your database in phpMyAdmin
-- Do NOT include database creation commands for shared hosting

-- Users table
CREATE TABLE IF NOT EXISTS `users` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `username` varchar(50) NOT NULL,
    `email` varchar(100) NOT NULL,
    `mobile` varchar(15) NOT NULL,
    `password` varchar(255) NOT NULL,
    `referral_code` varchar(20) DEFAULT NULL,
    `referred_by` varchar(20) DEFAULT NULL,
    `total_points` int(11) DEFAULT 0,
    `redeemed_points` int(11) DEFAULT 0,
    `badge` enum('NONE','SILVER','GOLD','PLATINUM','ELITE') DEFAULT 'NONE',
    `products_bought` int(11) DEFAULT 0,
    `status` enum('active','inactive') DEFAULT 'active',
    `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `username` (`username`),
    UNIQUE KEY `email` (`email`),
    UNIQUE KEY `referral_code` (`referral_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Categories table
CREATE TABLE IF NOT EXISTS `categories` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `name` varchar(100) NOT NULL,
    `description` text,
    `image` varchar(255) DEFAULT NULL,
    `status` enum('active','inactive') DEFAULT 'active',
    `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Products table
CREATE TABLE IF NOT EXISTS `products` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `name` varchar(255) NOT NULL,
    `description` text,
    `price` decimal(10,2) NOT NULL,
    `discount_price` decimal(10,2) DEFAULT 0.00,
    `category_id` int(11) DEFAULT NULL,
    `image` varchar(255) DEFAULT NULL,
    `stock_quantity` int(11) DEFAULT 0,
    `points_reward` int(11) DEFAULT 3,
    `button_type` enum('add_to_cart','shop_now','inquiry_now') DEFAULT 'add_to_cart',
    `status` enum('active','inactive') DEFAULT 'active',
    `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `category_id` (`category_id`),
    CONSTRAINT `products_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Cart table
CREATE TABLE IF NOT EXISTS `cart` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `user_id` int(11) NOT NULL,
    `product_id` int(11) NOT NULL,
    `quantity` int(11) DEFAULT 1,
    `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `user_id` (`user_id`),
    KEY `product_id` (`product_id`),
    CONSTRAINT `cart_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
    CONSTRAINT `cart_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Wishlist table
CREATE TABLE IF NOT EXISTS `wishlist` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `user_id` int(11) NOT NULL,
    `product_id` int(11) NOT NULL,
    `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `user_id` (`user_id`),
    KEY `product_id` (`product_id`),
    CONSTRAINT `wishlist_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
    CONSTRAINT `wishlist_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Orders table
CREATE TABLE IF NOT EXISTS `orders` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `user_id` int(11) NOT NULL,
    `order_number` varchar(50) NOT NULL,
    `total_amount` decimal(10,2) NOT NULL,
    `points_used` int(11) DEFAULT 0,
    `final_amount` decimal(10,2) NOT NULL,
    `status` enum('pending','confirmed','shipped','delivered','cancelled') DEFAULT 'pending',
    `shipping_address` text NOT NULL,
    `payment_method` varchar(50) DEFAULT 'UPI',
    `payment_status` enum('pending','completed','failed') DEFAULT 'pending',
    `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `order_number` (`order_number`),
    KEY `user_id` (`user_id`),
    CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Order items table
CREATE TABLE IF NOT EXISTS `order_items` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `order_id` int(11) NOT NULL,
    `product_id` int(11) NOT NULL,
    `quantity` int(11) NOT NULL,
    `price` decimal(10,2) NOT NULL,
    `points_earned` int(11) DEFAULT 0,
    PRIMARY KEY (`id`),
    KEY `order_id` (`order_id`),
    KEY `product_id` (`product_id`),
    CONSTRAINT `order_items_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
    CONSTRAINT `order_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Product ratings table
CREATE TABLE IF NOT EXISTS `product_ratings` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `user_id` int(11) NOT NULL,
    `product_id` int(11) NOT NULL,
    `rating` int(11) NOT NULL CHECK (`rating` >= 1 AND `rating` <= 5),
    `comment` text,
    `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `user_id` (`user_id`),
    KEY `product_id` (`product_id`),
    CONSTRAINT `product_ratings_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
    CONSTRAINT `product_ratings_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Points history table
CREATE TABLE IF NOT EXISTS `points_history` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `user_id` int(11) NOT NULL,
    `points` int(11) NOT NULL,
    `type` enum('earned','redeemed','referral','admin_added') NOT NULL,
    `description` text,
    `order_id` int(11) DEFAULT NULL,
    `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `user_id` (`user_id`),
    KEY `order_id` (`order_id`),
    CONSTRAINT `points_history_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
    CONSTRAINT `points_history_ibfk_2` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Referrals table
CREATE TABLE IF NOT EXISTS `referrals` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `referrer_id` int(11) NOT NULL,
    `referred_user_id` int(11) NOT NULL,
    `points_earned` int(11) DEFAULT 10,
    `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `referrer_id` (`referrer_id`),
    KEY `referred_user_id` (`referred_user_id`),
    CONSTRAINT `referrals_ibfk_1` FOREIGN KEY (`referrer_id`) REFERENCES `users` (`id`),
    CONSTRAINT `referrals_ibfk_2` FOREIGN KEY (`referred_user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Admin table
CREATE TABLE IF NOT EXISTS `admin` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `username` varchar(50) NOT NULL,
    `password` varchar(255) NOT NULL,
    `secret_key` varchar(255) DEFAULT NULL,
    `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `username` (`username`),
    UNIQUE KEY `secret_key` (`secret_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Website settings table
CREATE TABLE IF NOT EXISTS `website_settings` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `setting_name` varchar(100) NOT NULL,
    `setting_value` text,
    `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `setting_name` (`setting_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Banners table
CREATE TABLE IF NOT EXISTS `banners` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `title` varchar(255) NOT NULL,
    `image` varchar(255) NOT NULL,
    `link` varchar(255) DEFAULT NULL,
    `position` varchar(50) DEFAULT 'main',
    `status` enum('active','inactive') DEFAULT 'active',
    `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Cash redemption requests table
CREATE TABLE IF NOT EXISTS `cash_redemption_requests` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `user_id` int(11) NOT NULL,
    `points_redeemed` int(11) NOT NULL,
    `cash_amount` decimal(10,2) NOT NULL,
    `status` enum('pending','approved','rejected') DEFAULT 'pending',
    `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `processed_at` timestamp NULL DEFAULT NULL,
    PRIMARY KEY (`id`),
    KEY `user_id` (`user_id`),
    CONSTRAINT `cash_redemption_requests_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ========================================
-- INSERT DEFAULT DATA
-- ========================================

-- Insert default admin user (password: password)
INSERT INTO `admin` (`username`, `password`, `secret_key`) VALUES 
('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin_secret_key_2024');

-- Insert default categories
INSERT INTO `categories` (`name`, `description`, `image`) VALUES 
('Electronics', 'Electronic gadgets and accessories', 'electronics.jpg'),
('Fashion', 'Clothing and fashion accessories', 'fashion.jpg'),
('Home & Kitchen', 'Home appliances and kitchen items', 'home_kitchen.jpg'),
('Beauty & Personal Care', 'Beauty and personal care products', 'beauty.jpg'),
('Sports & Fitness', 'Sports and fitness equipment', 'sports.jpg'),
('Books & Stationery', 'Books, notebooks and stationery items', 'books.jpg');

-- Insert default website settings
INSERT INTO `website_settings` (`setting_name`, `setting_value`) VALUES 
('site_title', 'ShopEasy - Your Online Shopping Destination'),
('site_theme', 'light'),
('banner_text', 'Welcome to ShopEasy! Get amazing deals on all products with free shipping'),
('upi_id', 'shopeasy@upi'),
('whatsapp_number', '+919876543210'),
('points_to_cash_ratio', '2'),
('minimum_redeem_points', '100'),
('shipping_charge', '50'),
('free_shipping_limit', '500');

-- Insert sample products
INSERT INTO `products` (`name`, `description`, `price`, `discount_price`, `category_id`, `image`, `stock_quantity`, `points_reward`, `button_type`) VALUES 
('Smartphone Android 12', 'Latest Android smartphone with 6GB RAM, 128GB storage, dual camera', 15000.00, 12000.00, 1, 'smartphone.jpg', 50, 5, 'add_to_cart'),
('Gaming Laptop', 'High-performance laptop for work and gaming with RTX graphics', 45000.00, 40000.00, 1, 'laptop.jpg', 20, 10, 'add_to_cart'),
('Cotton T-Shirt', 'Comfortable cotton t-shirt available in various colors and sizes', 500.00, 300.00, 2, 'tshirt.jpg', 100, 3, 'add_to_cart'),
('Denim Jeans', 'Stylish denim jeans for men and women, premium quality', 1200.00, 800.00, 2, 'jeans.jpg', 75, 4, 'add_to_cart'),
('Kitchen Blender', 'High-speed blender for smoothies and shakes, 1000W motor', 2500.00, 2000.00, 3, 'blender.jpg', 30, 5, 'add_to_cart'),
('Face Cream', 'Anti-aging face cream with natural ingredients', 800.00, 600.00, 4, 'facecream.jpg', 60, 3, 'add_to_cart'),
('Yoga Mat', 'Premium yoga mat for fitness and exercise, non-slip surface', 1500.00, 1200.00, 5, 'yogamat.jpg', 40, 4, 'add_to_cart'),
('Study Notebook', 'High-quality notebook for students, 200 pages', 150.00, 100.00, 6, 'notebook.jpg', 200, 2, 'add_to_cart');

-- Insert sample banners
INSERT INTO `banners` (`title`, `image`, `link`, `position`, `status`) VALUES 
('Summer Sale - Up to 70% Off', 'banner1.jpg', '#', 'main', 'active'),
('New Arrivals - Fashion Collection', 'banner2.jpg', '#', 'main', 'active'),
('Electronics Mega Sale', 'banner3.jpg', '#', 'main', 'active');

-- ========================================
-- AUTO INCREMENT RESET
-- ========================================
ALTER TABLE `users` AUTO_INCREMENT = 1;
ALTER TABLE `categories` AUTO_INCREMENT = 7;
ALTER TABLE `products` AUTO_INCREMENT = 9;
ALTER TABLE `admin` AUTO_INCREMENT = 2;
ALTER TABLE `website_settings` AUTO_INCREMENT = 10;
ALTER TABLE `banners` AUTO_INCREMENT = 4;